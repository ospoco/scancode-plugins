A ScanCode Toolkit plugin to provide pre-built binary libraries and utilities and their locations.
